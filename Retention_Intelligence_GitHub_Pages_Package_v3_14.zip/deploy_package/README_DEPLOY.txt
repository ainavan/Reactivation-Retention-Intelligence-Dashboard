RETENTION INTELLIGENCE — UPDATED GITHUB PAGES PACKAGE

This package uses the latest dashboard file (v3.14 Supabase login) and names it index.html so GitHub Pages serves it as the repository homepage.

Existing repository: ainavan/Reactivation-Retention-Intelligence-Dashboard

UPLOAD STEPS (use the existing repository; do not create a new one):
1. Open the repository on GitHub.
2. Upload/replace index.html in the repository root with this package's index.html.
3. Commit the change to branch main.
4. Check Settings > Pages: Deploy from a branch; main; /(root).
5. Wait for the Pages deployment to finish, then open the repository's Pages URL.

PASSWORD RESET CONFIGURATION (after the public Pages URL is live):
1. In Supabase Authentication > URL Configuration, set Site URL to the exact public Pages URL.
2. Add that exact URL/path to Redirect URLs (or a suitable repository-path wildcard if supported).
3. Save.
4. Test Forgot Password only from the published HTTPS dashboard. This version blocks file:// and localhost reset requests and redirects recovery back to the hosted dashboard page.

SECURITY: The browser file contains only the Supabase publishable key. Never publish a service_role key.

NOTE: This package does not upload to GitHub or change Supabase settings automatically.
